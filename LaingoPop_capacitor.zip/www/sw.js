/* LaingoPop service worker v4: offline shell, background reminders (where the browser allows), notification clicks */
const VER='laingopop-v49-voice-soon',CFG='yaad-cfg';
const SHELL=['./','index.html','native-alarm.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/icon-maskable-512.png','icons/apple-touch-icon.png','icons/favicon-64.png','assets/scare-1.jpg','assets/scare-2.jpg','assets/scare-3.jpg'];
const RUNTIME_HOSTS=['cdnjs.cloudflare.com','fonts.googleapis.com','fonts.gstatic.com'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VER).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VER&&k!==CFG).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const req=e.request;if(req.method!=='GET')return;
  const url=new URL(req.url),same=url.origin===self.location.origin;
  if(!same&&!RUNTIME_HOSTS.includes(url.hostname))return;
  if(req.mode==='navigate'){
    e.respondWith(fetch(req).then(res=>{const cp=res.clone();caches.open(VER).then(c=>c.put(req,cp));return res}).catch(()=>caches.match(req,{ignoreSearch:true}).then(hit=>hit||caches.match('index.html'))));
    return;
  }
  e.respondWith(caches.match(req,{ignoreSearch:same}).then(hit=>{
    const net=fetch(req).then(res=>{if(res&&(res.ok||res.type==='opaque')){const cp=res.clone();caches.open(VER).then(c=>c.put(req,cp))}return res}).catch(()=>hit);
    return hit||net;
  }));
});
async function getCfg(){const c=await caches.open(CFG),r=await c.match('cfg');return r?r.json():{cfg:null,fired:[]}}
async function putCfg(o){const c=await caches.open(CFG);await c.put('cfg',new Response(JSON.stringify(o)))}
async function show(payload={}){const o=await getCfg(),title=payload.title||(o.cfg&&o.cfg.title)||'LaingoPop',body=payload.body||(o.cfg&&o.cfg.body)||'A few words are waiting. Tap to answer.';return self.registration.showNotification(title,{body,tag:payload.tag||'laingopop-reminder',requireInteraction:true,icon:'icons/icon-192.png',badge:'icons/icon-192.png',vibrate:[600,150,600,150,600,150,600,150,600,150,600],renotify:true,actions:[{action:'open',title:'Practice now'},{action:'later',title:'Later'}],data:{url:payload.url||'./?action=quiz&alarm=1',type:'quiz'}})}
async function check(){
  const o=await getCfg();if(!o.cfg||!o.cfg.on)return;
  const now=new Date(),day=now.toDateString();
  const times=(o.cfg.times&&o.cfg.times.length?o.cfg.times:(o.cfg.fixed||[])).map(t=>(t==='00:00'||t==='12:00')?'23:58':t);
  o.fired=(o.fired||[]).filter(k=>k.startsWith(day));
  for(const t of times){
    const [h,m]=t.split(':').map(Number),at=new Date(now);at.setHours(h,m,0,0);
    const diff=now-at,key=day+'@'+t;
    if(diff>=0&&diff<30*60000&&!o.fired.includes(key)){o.fired.push(key);await putCfg(o);await show();return}
  }
  await putCfg(o);
}
self.addEventListener('message',e=>{if(e.data&&e.data.type==='cfg'){e.waitUntil(getCfg().then(o=>{o.cfg=e.data.cfg;return putCfg(o)}).then(check))}});
self.addEventListener('periodicsync',e=>{if(e.tag==='yaad-check')e.waitUntil(check())});
self.addEventListener('push',e=>{let p={};try{p=e.data?e.data.json():{}}catch{try{p={body:e.data?.text()||''}}catch{}}e.waitUntil(show(p))});
self.addEventListener('pushsubscriptionchange',e=>{e.waitUntil(self.clients.matchAll({includeUncontrolled:true}).then(l=>l.forEach(c=>c.postMessage({type:'resub'}))))});
self.addEventListener('notificationclick',e=>{
  if(e.action==='later'){e.notification.close();return}
  e.notification.close();
  const target=(e.notification.data&&e.notification.data.url)||'./?action=quiz';
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    for(const c of list){if('focus' in c){c.postMessage({type:'quiz'});return c.focus()}}
    return self.clients.openWindow(target);
  }));
});
